Lab Assets - Proactive Customer Intelligence
Generated for 4 September 2026

Copy these files into C:\Users\Public\Desktop\Lab Assets on the JumpVM,
overwriting the existing versions.

accounts.csv          Prerequisite Task 4. Import into the Account table.
                      10 accounts. Accept the possible matches for
                      ContractRenewalDate and CurrentHealthTier.
                      Leave PrimaryContactEmail unmapped.

cases-baseline.csv    Prerequisite Task 4. Import into the Case table.
                      57 rows: 45 Resolved with CSAT and resolution values,
                      12 Active/High as the open critical cases.
                      ACC-1001 deliberately has no cases.

                      Map: CaseTitle -> title
                           AccountName -> customeridname
                           Priority -> prioritycode
                           Status -> statuscode
                           CreatedOn -> createdon
                           CSATScore -> cchs_csatscore
                           ResolutionHours -> cchs_resolutionhours

                      KNOWN ISSUE: the Case Customer field is a polymorphic
                      lookup and the CSV importer does not expose customerid,
                      only the read-only customeridname label. Dataverse may
                      reject the rows with "You should specify a contact or
                      account". If that happens, the cases must be created
                      by a loader flow or by hand.

accounts-round2.csv   Challenge 02 Task 6. Updated renewal dates for the five
cases-round2.csv      deteriorating accounts, and their replacement case set.

cases-recovery.csv    Challenge 05 Task 4. Post-recovery case set for ACC-1008.

Expected baseline scores once the data is in place:
  ACC-1001 100 Green    ACC-1006  53 Amber
  ACC-1002  97 Green    ACC-1007  44 Amber
  ACC-1003  94 Green    ACC-1008  26 Red
  ACC-1004  87 Green    ACC-1009  20 Red
  ACC-1005  67 Amber    ACC-1010  18 Red
